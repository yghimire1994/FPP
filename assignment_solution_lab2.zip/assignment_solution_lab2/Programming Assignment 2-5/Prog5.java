package fifth;

import java.util.Scanner;

public class Prog5 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter any string");
		
		String input=sc.nextLine();
		sc.close();
	
	String output="";
	for(int i=input.length()-1;i>=0;i--) {
		//output=output+input.substring(i,i+1);
		output=output+input.charAt(i);
		
	}
		System.out.println("output : "+output);
		
	}

}
